if [ -f /data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a/etc/profile.d/dependencies-setup.sh ]; then . /data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a/etc/profile.d/dependencies-setup.sh; fi
TRITON_INFERENCE_CLIENT_ROOT="/data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a"
TRITON_INFERENCE_CLIENT_VERSION="2.20.0-8fb2a41a883ad1b724a0bec1a825977a"
TRITON_INFERENCE_CLIENT_REVISION="1"
TRITON_INFERENCE_CLIENT_CATEGORY="external"
[ ! -d /data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a/bin ] || export PATH="/data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a/bin${PATH:+:$PATH}";
[ ! -d /data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a/lib ] || export LD_LIBRARY_PATH="/data/sonic/ragged/test/build4/slc7_amd64_gcc10/external/triton-inference-client/2.20.0-8fb2a41a883ad1b724a0bec1a825977a/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}";

