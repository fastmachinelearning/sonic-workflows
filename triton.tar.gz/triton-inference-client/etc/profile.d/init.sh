if [ -f /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e/etc/profile.d/dependencies-setup.sh ]; then . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e/etc/profile.d/dependencies-setup.sh; fi
TRITON_INFERENCE_CLIENT_ROOT="/data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e"
TRITON_INFERENCE_CLIENT_VERSION="2.24.0-fe61be7e854f9e00449eff2ff39beb1e"
TRITON_INFERENCE_CLIENT_REVISION="1"
TRITON_INFERENCE_CLIENT_CATEGORY="external"
[ ! -d /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e/bin ] || export PATH="/data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e/bin${PATH:+:$PATH}";
[ ! -d /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e/lib ] || export LD_LIBRARY_PATH="/data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/triton-inference-client/2.24.0-fe61be7e854f9e00449eff2ff39beb1e/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}";

