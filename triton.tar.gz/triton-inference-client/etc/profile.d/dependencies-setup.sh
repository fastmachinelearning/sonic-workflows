if [ "X${_CMSBUILD_BUILD_ENV_}" = "X" ] ; then
  true
  test X$GCC_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/gcc/10.3.0-84898dea653199466402e67d73657f10/etc/profile.d/init.sh
  test X$ZLIB_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/zlib/1.2.11-71514f01d2850dfd0bcd391557259a58/etc/profile.d/init.sh
  test X$BZ2LIB_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/bz2lib/1.0.6-86270889250d9cb8193d1963706a39cb/etc/profile.d/init.sh
  test X$EXPAT_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/expat/2.1.0-e2e74851cebffc0aa0988d120ae74fcd/etc/profile.d/init.sh
  test X$DB6_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/db6/6.2.32-0f34c5862bf3098cbedece4ce9240238/etc/profile.d/init.sh
  test X$GDBM_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/gdbm/1.10-d603980cbd3ec2df3505d5b82740ee09/etc/profile.d/init.sh
  test X$LIBUUID_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/libuuid/2.34-fe91b21b8e54a48f2d45894d9da65f14/etc/profile.d/init.sh
  test X$SQLITE_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/sqlite/3.36.0-cdaed8943a1c7d35c738a99ec764027b/etc/profile.d/init.sh
  test X$LIBFFI_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/libffi/3.4.2-482b99521caf507051a7a5dce0eb5926/etc/profile.d/init.sh
  test X$XZ_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/xz/5.2.5-d6fed2038c4e8d6e04531d1adba59f37/etc/profile.d/init.sh
  test X$PYTHON3_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/python3/3.9.6-67e5cf5b4952101922f1d4c8474baa39/etc/profile.d/init.sh
  test X$PCRE_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/pcre/8.43-28d54724578a9006cf0dca75629374e3/etc/profile.d/init.sh
  test X$PROTOBUF_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/protobuf/3.15.1-7e10d5eb9143430224a15d6b61e33af1/etc/profile.d/init.sh
  test X$CUDA_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/cuda/11.5.2-c927b7e765e06433950d8a7eab9eddb4/etc/profile.d/init.sh
  test X$GRPC_ROOT != X || . /data/sonic/ragged/v2.24.0/build6/el8_amd64_gcc10/external/grpc/1.35.0-8947bdd6268fa123839ebc2720830618/etc/profile.d/init.sh
fi
